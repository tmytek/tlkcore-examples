import json
import os
from pathlib import Path
import socket
import sys
import traceback

root_path = Path(__file__).absolute().parent

# Please setup path of tlkcre libraries to environment variables,
# here is a example to search from 'lib/' or '.'
prefix = "lib/"
lib_path = os.path.join(root_path, prefix)
if os.path.exists(lib_path):
    sys.path.insert(0, os.path.abspath(lib_path))
else:
    print("Importing from source code")

from tlkcore.TMYCommService import TMYCommService
from tlkcore.TMYDFU import TMYDFU
from tlkcore.TMYPublic import RetCode, DevInterface
from tlkcore.TMYUtils import _Utils, RetType, ScanMode, _RspType as RspType
from tlkcore.tmydev.TMYTableManager import BeamPatternTableManager, AAKitTableManager

class TMYMiddleWare():
    def __init__(self):
        directory = os.path.join(root_path, 'tlk_comm_log/')
        if not os.path.isdir(directory):
            os.mkdir(directory)

        _Utils._initRoot(root_path)
        self.__service = TMYCommService(os.path.join(root_path, 'logging.conf'))
        self.beam_table_mgt = {}
        self.aakit_mgt = {}
        self.__pd_cali = {}

    # ----- Forwarding functions -----

    def __scan(self, *param):
        return self.__service.scanDevices(*param)

    def __connectToDevice(self, *param):
        return self.__service.connectDevice(*param)

    def __disconnect(self, sn):
        return self.__service.disConnDevice(sn)

    def __sendCMD(self, sn, *param):
        return self.__service.sendDevice(sn, *param)

    def __sendConnParam(self, sn, *param):
        return self.__service.setConnParam(sn, *param)

    def __dfu(self, dfu_dev_info, dfu_image):
        import time
        # Passing info & comm service to TMYDFU
        instance = TMYDFU(dfu_dev_info, self.__service)
        ret = instance.checkDFUHeader(dfu_image)
        if ret.RetCode is not RetCode.OK:
            return ret

        if dfu_dev_info["in_dfu"]:
            print("Device already in DFU mode")
        else:
            cmd_list = dfu_dev_info["cmd_list"]
            instance.setToDFUMode(cmd_list)

        ret = instance.transmit()
        if ret.RetCode is not RetCode.OK:
            return ret

        header = instance.getParsedHeader()

        # 1. Waiting for DUT rebooting
        wait_s = header["update_time"]
        print("Waiting for %ds..." %wait_s)
        for i in range(wait_s*2):
            print("%02d%%" %((i+1)/(wait_s*2)*100), end="\r")
            time.sleep(0.5)

        print("Waiting for %ds... Done, please try to rescan" %wait_s)
        # 2. Scan device
        # 3. Compare header FW version and current FW version
        return RetType()

    def __getCLCStat(self, sn):
        """Get Clover 2x2 data

        Args:
            sn (_type_): _description_
        """
        return self.__service._getCLCStat(sn)

    def __sendPD(self, sn, freq):
        """Get PD power value handling (other PD cmds please use __sendCMD())"""
        ret = self.__service.getCommState(sn)
        if ret.RetCode is not RetCode.OK:
            return ret
        if not ret.RetData:
            print("Detect PD not cennected, trying to reconnect and re-init & re-cali")
            # Re-plug PD must reboot
            ret = self.__service._reInitPD(sn)
            if ret.RetCode is not RetCode.OK:
                return ret
            # Init PD
            cmd = json.dumps({"CmdId":0x0, "Data":[""]}).strip()
            ret = self.__service._sendPD(sn, cmd)
            if ret.RetCode is not RetCode.OK:
                return ret
            # Cali config
            # print(self.__pd_cali[sn])
            for freq, config in self.__pd_cali[sn].items():
                cmd = json.dumps({"CmdId":0x06, "Data":[{freq: config}]}).strip()
                print("Send Cali: %s" %cmd)
                ret = self.__service._sendPD(sn, cmd)
                if ret.RetCode is not RetCode.OK:
                    return ret

        cmd = json.dumps({"CmdId":0x05, "Data":[freq]}).strip() + "\r\n"
        ret = self.__service._sendPD(sn, cmd)
        # Error code and power value handling
        if ret.RetCode is RetCode.OK and ret.RetData == -1000:
            return RetType(RetCode.ERROR_PD_CALI, "Please calibrate PD")
        return ret

    def __updatePDCaliConfig(self, sn, config):
        self.__pd_cali[sn] = config
        return RetType()

    # Forward local BeamTable functions
    def __forwardBeamTable(self, sn, func_name, **kwarg):
        bt = self.beam_table_mgt.get(sn)
        print("__forwardBeamTable: %s" %kwarg)

        if func_name == '_load':
            left = {
                    'freq': kwarg['freq'],
                    'aakit': kwarg['aakit']
                }
            if bt is None:
                kwarg['sn'] = sn
                del kwarg['freq']
                del kwarg['aakit']
                print("New BeamPatternTableManager with: %s" %kwarg)
                self.beam_table_mgt[sn] = BeamPatternTableManager(**kwarg)

            # Left keys for _load()
            kwarg = left.copy()

        if hasattr(self.beam_table_mgt[sn], func_name):
            print("Call func: %s with: %s" %(func_name, kwarg))
            return getattr(self.beam_table_mgt[sn], func_name)(**kwarg)
        else:
            ret = RetType(RetCode.ERROR_METHOD_NOT_FOUND, "BeamTableMgt func %s() not exist or not ready at this state" %func_name)
            print(ret.RetMsg)
            return ret

    # Forward local AAKit functions
    def __getLocalAAKit(self, sn, dev_type, ch, support_devs):
        aakit = self.aakit_mgt.get(sn)
        if aakit is None:
            self.aakit_mgt[sn] = AAKitTableManager(dev_type, ch, support_dev=support_devs)
        ret = self.aakit_mgt[sn].parse()
        if ret.RetCode is not RetCode.OK:
            return ret
        return self.aakit_mgt[sn].getAAKitInfo(local=True)

    def __forwardAAKitCustom(self, sn, func_name, **kwarg):
        aakit = self.aakit_mgt.get(sn)
        if aakit is None:
            ret = RetType(RetCode.ERROR_BF_AAKIT, "[Mid] Not yet getAAKitList")
            print(ret.RetMsg)
            return ret
        print("__forwardAAKitCustom: %s" %kwarg)
        if hasattr(self.aakit_mgt[sn], func_name):
            return getattr(self.aakit_mgt[sn], func_name)(**kwarg)
        else:
            ret = RetType(RetCode.ERROR_METHOD_NOT_FOUND, "AAKit func %s() not exist or not ready at this state" %func_name)
            print(ret.RetMsg)
            return ret

    # ----- Middle function -----

    def __connectToServer(self, host="127.0.0.1", port=55688):
        """Connect to fake cloud side"""
        try:
            tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            tcp.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            tcp.settimeout(3)

            tcp.connect((host, port))
            return tcp
        except socket.timeout:
            traceback.print_exc()

        return None

    def running(self, host="127.0.0.1", port=55688):
        conn = self.__connectToServer(host, port)
        if conn is None:
            print("Connect to server failed")
            return

        while conn is not None:
            try:
                indata = conn.recv(64000)
                if len(indata) == 0: # connection closed
                    conn.close()
                    print('client closed connection.')
                    break
                data = indata.decode().strip()
                print('[RecvMsg]:\r\n' + data)

                mid = json.loads(data)
                cmd = mid["cmd"]
                if cmd == "scan":
                    ret = self.__scan(ScanMode(mid["scanMode"]), DevInterface(mid["interface"]))
                elif cmd == "beam_table":
                    # For all other beam_table functions
                    args = mid['args']
                    # print(mid)
                    ret = self.__forwardBeamTable(mid['sn'], mid['func_name'], **args)
                elif cmd == "dfu":
                    # NOTE: A HARD CODE example for dfu, please modify it to your own dfu image
                    img = "ris_dfu.tbin"
                    ret = self.__dfu(mid['info'], img)
                elif cmd == "getAAKit":
                    ret = self.__getLocalAAKit(mid['sn'],
                                              mid['dev_type'],
                                              mid['ch'],
                                              mid['suppDevs'])
                elif cmd == "aakit":
                    # For all other aakit functions
                    args = mid['args']
                    ret = self.__forwardAAKitCustom(mid['sn'], mid['func_name'], **args)
                elif cmd == "clc_stat":
                    ret = self.__getCLCStat(mid['sn'])
                elif cmd == "pd_power":
                    ret = self.__sendPD(mid['sn'], mid['freq'])
                elif cmd == "pd_cali":
                    # For FW->middle
                    ret = self.__updatePDCaliConfig(mid['sn'], mid['config'])
                else:
                    # from sendCmd
                    if cmd.__contains__("disconnect"):
                        ret = self.__disconnect(mid['sn'])
                    elif cmd.__contains__("connect:"):
                        line = cmd.replace("connect:", "").strip()
                        arr = line.split(':')
                        addr = arr[0]
                        interface = DevInterface(int(arr[1]))
                        timeout = None
                        if len(arr) > 2:
                            timeout = arr[2]
                        ret = self.__connectToDevice(mid['sn'], addr, interface)
                    elif cmd.__contains__("conn_param:"):
                        line = cmd.replace("conn_param:", "").strip()
                        arr = line.split(':')
                        ret = self.__sendConnParam(mid['sn'], int(arr[0]))
                    else:
                        rspType = RspType(mid['rspType'])
                        if rspType is RspType.RSP_LIST:
                            cmd = bytearray(cmd)
                        ret = self.__sendCMD(mid['sn'], cmd, rspType)
                outdata = ret.toJson()
                print("[RSP]:\n" + outdata)
                conn.send(outdata.encode('utf-8'))
            except (KeyboardInterrupt, SystemExit):
                print("Detect Ctrl+C")
                break
            except socket.timeout:
                print("Timeout, wait again")
            except ConnectionAbortedError:
                print("Connection aborting")
                break
            except ConnectionResetError:
                print("Connection resetting")
                break
            except:
                traceback.print_exc()
                break

        conn.close()

if __name__ == '__main__':
    m = TMYMiddleWare()
    m.running(host="127.0.0.1")
    print("end")