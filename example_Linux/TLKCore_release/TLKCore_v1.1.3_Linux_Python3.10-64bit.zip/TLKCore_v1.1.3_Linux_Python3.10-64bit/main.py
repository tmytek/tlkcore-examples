import logging
import logging.config
import os
from pathlib import Path
import platform
import sys
import time
import traceback

try:
    from lib.TLKCoreService import TLKCoreService
    from lib.TMYPublic import DevInterface, RetCode, RFMode, UDState, UDMState, BeamType, UDM_REF
except ModuleNotFoundError as e:
    print(e.msg)
    if e.msg.__contains__("No module named \'lib"):
        print("Loading from src/")
        from src.TLKCoreService import TLKCoreService
        from src.TMYPublic import DevInterface, RetCode, RFMode, UDState, UDMState, BeamType, UDM_REF
    else:
        print("[Main] lib exist but some packages loading failed, please check pip install -r requirements.txt")
        traceback.print_exc()
        os._exit(-1)
except Exception as e:
    traceback.print_exc()
    os._exit(-1)

caliConfig = [
    {
        "0.1GHz": {
            "lowPower": -35,
            "lowVolt": 34.68,
            "highPower": -5,
            "highVolt": 901.68
            }
    },
    {
        "0.3GHz": {
            "lowPower": -35,
            "lowVolt": 34.68,
            "highPower": -5,
            "highVolt": 901.68
            }
    },
    {
        "0.5GHz": {
            "lowPower": -36,
            "lowVolt": 109.98,
            "highPower": -5,
            "highVolt": 984.18
            }
    },
    {
        "1GHz": {
            "lowPower": -36,
            "lowVolt": 109.98,
            "highPower": -5,
            "highVolt": 984.18
            }
    },
    {
        "10GHz": {
            "lowPower": -36,
            "lowVolt": 57.6,
            "highPower": -5,
            "highVolt": 950.4
            }
    },
    {
        "20GHz": {
            "lowPower": -36,
            "lowVolt": 40.46,
            "highPower": -5,
            "highVolt": 936.36
            }
    },
    {
        "30GHz": {
            "lowPower": -36,
            "lowVolt": 83.81,
            "highPower": -5,
            "highVolt": 979.71
            }
    },
    {
        "40GHz": {
            "lowPower": -31,
            "lowVolt": 20.65,
            "highPower": -5,
            "highVolt": 787.65
            }
    },
    {
        "43GHz": {
            "lowPower": -31,
            "lowVolt": 20.65,
            "highPower": -5,
            "highVolt": 787.65
            }
    }
]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        # logging.FileHandler(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'debug.log')),
    ]
)

logger = logging.getLogger("Main")
logger.info("Python v%d.%d.%d (%s) on the %s platform" %(sys.version_info.major,
                                            sys.version_info.minor,
                                            sys.version_info.micro,
                                            platform.architecture()[0],
                                            platform.system()))

service = None
root_path = Path(__file__).absolute().parent

class TMYLogFileHandler(logging.FileHandler):
    """Handle relative path to absolute path"""
    def __init__(self, fileName, mode):
        super(TMYLogFileHandler, self).__init__(os.path.join(root_path, fileName), mode)

def wrapper(*args, **kwarg):
    """It's a wrapper function to help some API developers who can't call TLKCoreService class driectly,
    so developer must define return type if using LabVIEW/MATLAB"""
    global service
    if len(args) == 0:
        logger.error("Invalid parameter: please passing function name and parameters")
        raise Exception
    if service is None:
        service = TLKCoreService(log_path=os.path.join(root_path, 'logging_abs.conf'))
        logger.info("TLKService v%s %s" %(service.queryTLKCoreVer(), "is running" if service.running else "can not run"))
        logger.info(sys.path)

    arg_list = list(args)
    func_name = arg_list.pop(0)
    logger.info("Calling dev_func: \'%s()\'with %r and %r" % (func_name, arg_list, kwarg))
    if not hasattr(service, func_name):
        logger.error("TLKService not support %s()" %func_name)
        raise Exception

    # Parsing each arg_list if includes TMY enum
    # p = "RFMode.TX"
    # str_list = p.split('.')
    # type_str = str_list[0]
    # value_str = str_list[1]
    # f = globals()[type_str]
    # print(f)
    # v = getattr(f, value_str)
    # print(v)
    for i in range(1, len(arg_list)): # skip first for sn
        p = arg_list[i]
        if type(p) is str and p.__contains__('.'):
            try:
                # Parsing and update to enum type
                logger.debug("Parsing: %s" %p)
                str_list = p.split('.')
                type_str = str_list[0]
                value_str = str_list[1]
                f = globals()[type_str]
                v = getattr(f, value_str)
                arg_list[i] = v
            except Exception as e:
                logger.exception("TLKService arg parsed failed")
                raise e

    # Relfect and execute function in TLKCoreService
    ret = getattr(service, func_name)(*tuple(arg_list))
    if ret.RetCode is not RetCode.OK:
        logger.error("%s() returned: %s" %(func_name, ret.RetMsg))
        raise Exception

    if ret.RetData is None:
        logger.info("%s() returned: %s" %(func_name, ret.RetCode))
        return str(ret.RetCode)
    else:
        logger.info("%s() returned: %s" %(func_name, ret.RetData))
        return ret.RetData

def startService():
    """ALL return type from TLKService always be RetType,
    and it include: RetCode, RetMsg, RetData,
    you could fetch service.func().RetData
    or just print string result directly if you make sure it always OK"""
    service = TLKCoreService()
    logger.info("TLKService v%s %s" %(service.queryTLKCoreVer(), "is running" if service.running else "can not run"))
    # logger.info(sys.path)

    if service.running:
        # Please select or combine your interface or not pass any parameters: service.scanDevices()
        interface = DevInterface.ALL #DevInterface.LAN | DevInterface.COMPORT
        logger.info("Set finding devices via: %s" %interface)
        ret = service.scanDevices(interface=interface)

        scanlist = ret.RetData
        logger.info("Scanned device list: %s" %scanlist)

        if ret.RetCode is not RetCode.OK:
            if len(scanlist) == 0:
                logger.warning(ret.RetMsg)
                return False
            else:
                input(" === There is some errors while scanning, do you want to continue? ===")

        for i in range(0, len(scanlist)):
            data = scanlist[i].rstrip('\x00').split(',')
            if len(data) < 2 or len(data) > 3:
                logger.error("Can't parse scan result: %s" %scanlist[i])
                return False
            sn = data[0].strip()
            addr = data[1].strip()
            devtype = 0
            if len(data) == 3:
                devtype = int(data[2].strip())
            logger.info("Dev list(%d): %s, %s, %d" %(i, sn, addr, devtype))

            # print(service.getScanInfo(sn).RetData[1])
            if service.initDev(sn).RetCode is not RetCode.OK:
                continue
            logger.info("FW ver: %s" %service.queryFWVer(sn))
            logger.info("SN: %s" %service.querySN(sn))
            logger.info("HW ver: %s" %service.queryHWVer(sn))

            dev_name = service.getDevTypeName(sn)
            # print(dev_name)

            # Process device testing
            if 'BBoard' in dev_name:
                dev_name = "BBoard"
            elif 'BBox' in dev_name:
                dev_name = "BBox"
            f = globals()["test"+dev_name]
            kw = {}
            kw['sn'] = sn
            kw['service'] = service
            f(**kw)

            service.DeInitDev(sn)
        return True
    return False

def testPD(sn, service):
    for config in caliConfig:
        logger.info("Process cali: %s" %service.setCaliConfig(sn, config))

    for _ in range(10):
        logger.info("Fetch voltage: %s" %service.getVoltageValue(sn, 28))
        logger.info("        power: %s" %service.getPowerValue(sn, 28))
    logger.info("Reboot test: %s" %service.reboot(sn))

    while(True):
        try:
            logger.info("power: %s" %(service.getPowerValue(sn, 28)))
            time.sleep(0.5)
        except (KeyboardInterrupt, SystemExit):
            print("Detect Ctrl+C")
            break

def testUDBox(sn, service):
    logger.info("PLO state: %r" %service.getUDState(sn, UDState.PLO_LOCK).RetData)
    logger.info("All state: %r" %service.getUDState(sn).RetData)
    logger.info(service.setUDState(sn, 0, UDState.CH1))
    input("Wait for ch1 off")
    # logger.info(service.setUDState(sn, 1, UDState.SOURCE_100M))
    logger.info(service.setUDState(sn, 1, UDState.CH1))
    logger.info(service.setUDState(sn, 1, UDState.CH2))
    logger.info(service.setUDState(sn, 1, UDState.OUT_10M))
    logger.info(service.setUDState(sn, 1, UDState.OUT_100M))
    logger.info(service.setUDState(sn, 1, UDState.PWR_5V))
    logger.info(service.setUDState(sn, 1, UDState.PWR_9V))
    input("Wait")
    # logger.info(service.setUDState(sn, 0, UDState.SOURCE_100M))

    logger.info("Freq config: %s" %service.getUDFreq(sn))
    logger.info("Check harmonic: %r" %service.getHarmonic(sn, 24000000, 28000000, 4000000, 100000).RetData)
    service.setUDFreq(sn, 24000000, 28000000, 4000000, 100000)
    logger.info("Freq config: %s" %service.getUDFreq(sn))

def testUDM(sn, service):
    # Just passing parameter via another way
    param = {"sn": sn}
    param['item'] = UDMState.REF_LOCK | UDMState.SYSTEM | UDMState.PLO_LOCK
    ret = service.getUDState(**param)
    if ret.RetCode is not RetCode.OK:
        return logger.error("Error to get UDM state: %s" %ret)
    logger.info("UDM state: %s" %ret)
    lock = ret.RetData[UDMState.REF_LOCK.name]

    # Passing parameter with normal way
    logger.info("UDM freq capability range: %s" %service.getUDFreqLimit(sn))
    logger.info("UDM available freq range : %s" %service.getUDFreqRange(sn))

    # service.reboot(sn)
    # input("Wait for rebooting...Please press ENTER to continue")

    logger.info("UDM current freq: %s" %service.getUDFreq(sn))
    service.setUDFreq(sn, 7000000, 10000000, 3000000, 100000)
    logger.info("UDM current freq: %s" %service.getUDFreq(sn))

    # We use reference config to try reference source switching
    source = service.getRefConfig(sn).RetData['source']
    logger.info("UDM current ref source setting: %s, and real reference status is: %s" %(source, lock))

    if source is UDM_REF.INTERNAL:
        # INTERNAL -> EXTERNAL
        source = UDM_REF.EXTERNAL
        # Get external reference source supported list
        supported = service.getRefFrequencyList(sn, source).RetData
        logger.info("Supported external reference clock(KHz): %s" %supported)
        # Try to change reference source to external: 10M
        ret = service.setRefSource(sn, source, supported[0])
        logger.info("Change UDM ref source to %s -> %s with freq: %d" %(source, ret, supported[0]))
        input("Waiting for external reference clock input")
    elif source is UDM_REF.EXTERNAL:
        # EXTERNAL -> INTERNAL
        source = UDM_REF.INTERNAL
        # Get internal reference source supported list
        supported = service.getRefFrequencyList(sn, source).RetData
        logger.info("Supported internal output reference clock(KHz): %s" %supported)
        # Try to change reference source to external: 10M
        ret = service.setRefSource(sn, source, supported[0])
        logger.info("Change UDM ref source to %s -> %s" %(source, ret))

        # Output 10MHz ref clock
        enable = not service.getOutputReference(sn).RetData
        output_freq = supported[0]
        logger.info("%s UDM ref output(%dKHz): %s"
                    %("Enable" if enable else "Disable", output_freq, service.setOutputReference(sn, enable, output_freq)))
        logger.info("Get UDM ref ouput: %s" %service.getOutputReference(sn))

        input("Typing ENTER to disable output")
        enable = not enable
        logger.info("%s UDM ref output: %s"
                    %("Enable" if enable else "Disable", service.setOutputReference(sn, enable, output_freq)))
        logger.info("Get UDM ref ouput: %s" %service.getOutputReference(sn))

    source = service.getRefConfig(sn).RetData
    lock = service.getUDState(sn, UDMState.REF_LOCK).RetData[UDMState.REF_LOCK.name]
    logger.info("UDM current ref source setting: %s, and real reference status is: %s" %(source, lock))

def testBBox(sn, service):
    logger.info("MAC: %s" %service.queryMAC(sn))
    logger.info("Static IP: %s" %service.queryStaticIP(sn))
    # Sample to passing parameter with dict
    # a = {}
    # a["ip"] = '192.168.100.122'
    # a["sn"] = sn
    # logger.info("Static IP: %s" %service.setStaticIP(**a))
    # logger.info("Export dev log: %s" %service.exportDevLog(sn))

    mode = RFMode.TX
    logger.info("Set RF mode: %s" %service.setRFMode(sn, mode).name)
    logger.info("Get RF mode: %s" %service.getRFMode(sn))

    ret = service.setOperatingFreq(sn, 28)
    if ret.RetCode is not RetCode.OK:
        logger.error("Set freq: %s" %ret.RetCode)
        ans = input("Do you want to continue to processing? (Y/N)")
        if ans.upper() == 'N':
            return
    logger.info("Set freq: %s" %ret.RetCode)
    logger.info("Get freq: %s" %service.getOperatingFreq(sn))
    logger.info("Cali ver: %s" %service.queryCaliTableVer(sn))

    # Gain setting for BBoxOne/Lite
    rng = service.getDR(sn, mode).RetData
    logger.info("DR range: %s" %rng)

    # Set/save AAKit
    # custAAKitName = 'MyAAKIT'
    # logger.info("Set AAKit: %s" %service.setAAKitInfo(sn,
    #                                                   custAAKitName,
    #                                                   ["0","0"],
    #                                                   ["-100","100"],
    #                                                   ["0","0"],
    #                                                   ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
    #                                                   ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"]))
    # logger.info("Save AAKit: %s" %service.saveAAKitFile(sn, custAAKitName))
    # logger.info("Get AAKitList: %s" %service.getAAKitList(sn))
    # logger.info("Get AAKitInfo: %s" %service.getAAKitInfo(sn, custAAKitName))

    # Select AAKit
    aakitList = service.getAAKitList(sn).RetData
    if aakitList is None:
        logger.warning("PhiA mode")
    for aakit in aakitList:
        if '4x4' in aakit:
            logger.info("Select AAKit: %s, return %s" %(aakit, service.selectAAKit(sn, aakit).name))
            break

    gain = rng[1]

    # Set IC channel gain without common gain
    logger.info("Set Gain of IC: %s" %service.setIcChannelGain(sn, 1, [gain,gain,gain,gain]))
    # Set IC channel gain with common gain, and gain means element gain(offset) if assign common gain
    com_dr = service.getCOMDR(sn).RetData
    board_idx = 0 # 0~3
    common_gain_rng = com_dr[mode.value][board_idx]
    logger.info("Common gain range: %s" %common_gain_rng)
    common_gain = (common_gain_rng[0] + common_gain_rng[1])/2
    ele_offsets = [1, 0 , 2, -1]
    logger.info("Set Gain of IC: %s" %service.setIcChannelGain(sn, 1, ele_offsets, common_gain))

    input("WAIT.........Set Gain/Phase:")
    logger.info("Set Gain/Phase: %s" %service.setChannelGainPhase(sn, 1, gain, 30))
    # logger.info("Set Gain/Phase: %s" %service.setChannelGainPhase(sn, 4, gain, 10))

    input("WAIT.........Channel Control - Disable")

    # Disable specific channel
    logger.info("Disable channel: %s" %service.switchChannel(sn, 1, True))
    logger.info("Disable channel: %s" %service.switchChannel(sn, 6, True))

    input("WAIT.........Channel Control - Enable")

    logger.info("Enable channel: %s" %service.switchChannel(sn, 1, False))
    logger.info("Enable channel: %s" %service.switchChannel(sn, 6, False))

    input("WAIT.........Beam Control")

    logger.info("SetBeamAngle-1: %s" %service.setBeamAngle(sn, gain, 0, 0))
    logger.info("SetBeamAngle-2: %s" %service.setBeamAngle(sn, gain, 10, 30))
    logger.info("SetBeamAngle-3: %s" %service.setBeamAngle(sn, gain, 2, 180))

    input("WAIT.........FBS Mode")

    # Beam pattern functions:
    logger.info("BeamId limit: %s" %service.getBeamIdStorage(sn))

    batch_import = True
    if batch_import:
        ret = appyBatchBeams(sn, service)
        if not ret:
            return
    else:
        beamID = 1
        # args = {'beamId': beamID, 'mode': RFMode.TX, 'sn': sn}
        # ret = service.getBeamPattern(**args)
        ret = service.getBeamPattern(sn, RFMode.TX, beamID)
        beam = ret.RetData
        logger.info("BeamID %d info: %s" %(beamID, beam))

        # Edit beam
        config = beam['beam_config']
        config['db'] = gain
        config['theta'] = 10
        config['phi'] = 30
        ret = service.setBeamPattern(sn, RFMode.TX, beamID, BeamType.BEAM, config)
        if ret.RetCode is not RetCode.OK:
            logger.error(ret.RetMsg)
            return

        # Edit custom beam with channel config
        beamID = 2
        ret = service.getBeamPattern(sn, RFMode.TX, beamID)
        beam = ret.RetData
        logger.info("BeamID %d info: %s" %(beamID, beam))
        config = beam['channel_config']

        # CH1, config[0] means the search result of config[x]['channel'] == 1
        config[0]['db'] -= 3
        config[0]['deg'] = 190
        # CH2
        config[1]['db'] -= 2
        config[1]['deg'] = 20
        # CH3
        config[2]['sw'] = 1
        # CH4
        config[3]['db'] -= 4
        ret = service.setBeamPattern(sn, RFMode.TX, beamID, BeamType.CHANNEL, config)
        if ret.RetCode is not RetCode.OK:
            logger.error(ret.RetMsg)
            return

    # FPGA mode
    service.setFastParallelMode(sn, True)

def appyBatchBeams(sn, service, path="CustomBatchBeams.csv"):
    """Test for parsing batch beam configs then apply it"""
    import csv
    try:
        file = open(path)
        reader = csv.reader(_.replace('\x00', '') for _ in file)
        custom = { 'TX': {}, 'RX': {}}
        # Parsing CSV
        for col in reader:
            if len(col) == 0 or len(col[0]) == 0 or col[0] == 'Mode':
                continue
            # col = line.split(',')
            mode_name = col[0]
            beamID = int(col[1])
            beam_type = BeamType(int(col[2]))

            if beam_type is BeamType.BEAM:
                # Fetch col 3~5 for db,theta,phi
                config = [col[i] for i in range(3, 6)]
            else: #CHANNEL
                ch = int(col[6])
                # Fetch col 7~9 for sw,db,deg
                config = {str(ch): [col[i] for i in range(7, 10)]}

            if custom[mode_name].get(str(beamID)) is None:
                # Create new beam config
                beam = {'beam_type': beam_type.value, 'config': config}
                custom[mode_name][str(beamID)] = beam
            else:
                # If exist, replace or add new channel config into beam config
                custom[mode_name][str(beamID)]['config'].update(config)
                # custom[mode_name][str(beamID)].update(beam)

        # Parsing done
        print(custom)

        mode = RFMode.TX
        # Get Beam then update custom beam
        for mode_name in [*custom]:
            for m in RFMode:
                if m.name == mode_name:
                    mode = m
            print(mode)
            for id in [*custom[mode_name]]:
                beamID = int(id)
                ret = service.getBeamPattern(sn, mode, beamID)
                beam = ret.RetData
                logger.info("Get [%s]BeamID %d info: %s" %(mode_name, beamID, beam))

                beam_type = BeamType(custom[mode_name][str(beamID)]['beam_type'])
                value = custom[mode_name][str(beamID)]['config']
                if beam_type is BeamType.BEAM:
                    config = beam['beam_config']
                    if len(value[0]) > 0:
                        config['db'] = float(value[0])
                    if len(value[1]) > 0:
                        config['theta'] = int(value[1])
                    if len(value[2]) > 0:
                        config['phi'] = int(value[2])
                else: #CHANNEL
                    config = beam['channel_config']
                    # Update each channel
                    for ch in [*value]:
                        ch_idx = int(ch) - 1
                        ch_value = value[ch]
                        if len(ch_value[0]) > 0:
                            config[ch_idx]['sw'] = int(ch_value[0])
                        if len(ch_value[1]) > 0:
                            config[ch_idx]['db'] = float(ch_value[1])
                        if len(ch_value[2]) > 0:
                            config[ch_idx]['deg'] = int(ch_value[2])
                ret = service.setBeamPattern(sn, mode, beamID, beam_type, config)
                if ret.RetCode is not RetCode.OK:
                    logger.error(ret.RetMsg)
                    return False
    except:
        logger.exception("Something wrong")
        return False
    return True

def testBBoard(sn, service):
    logger.info("Static IP: %s" %service.queryStaticIP(sn))
    logger.info("Set RF mode: %s" %service.setRFMode(sn, RFMode.TX).name)
    logger.info("Get RF mode: %s" %service.getRFMode(sn))

    ret = service.queryHWVer(sn)
    if "Unknown" in ret.RetData:
        logger.info("No HW ver")
    else:
        logger.info("HW Ver: %s" %ret.RetData)
        ret = service.getFrequencyList(sn)
        freq_list = ret.RetData
        # print(freq_list)
        if 28.0 in freq_list:
            ret = service.setOperatingFreq(sn, 28)
            logger.info("Set freq: %s" %ret.RetCode)
            logger.info("Get freq: %s" %service.getOperatingFreq(sn))
            logger.info("Cali ver: %s" %service.queryCaliTableVer(sn))

            # [Optional] Select AAKit then setBeamAngle
            aakitList = service.getAAKitList(sn).RetData
            for aakit in aakitList:
                if 'TMYTEK_28LITE_4x4_C2139L024-28' in aakit:
                    logger.info("Select AAKit: %s, return %s" %(aakit, service.selectAAKit(sn, aakit).name))
            rng = service.getDR(sn, RFMode.TX).RetData
            gain = rng[1]
            logger.info(service.setBeamAngle(sn, gain, 10, 30))
            return

    logger.info("TC ADC: %s" %service.getTemperatureADC(sn))
    service.setTCConfig(sn, [8, 6, 2, 9])

    input("WAIT.........")

    # Disable specific channel
    logger.info("Disable channel: %s" %service.switchChannel(sn, 1, True))
    logger.info("Disable channel: %s" %service.switchChannel(sn, 4, True))

    input("WAIT2.........")

    logger.info("Enable channel: %s" %service.switchChannel(sn, 1, False))
    logger.info("Enable channel: %s" %service.switchChannel(sn, 4, False))

    input("WAIT3.........")

    logger.info("Set phase step for ch(%d): %s" %(1, service.setChannelPhaseStep(sn, 1, 2)))
    logger.info("Set gain step for ch(%d): %s" %(1, service.setChannelGainStep(sn, 1, 8)))
    logger.info("Set phase step for ch(%d): %s" %(3, service.setChannelPhaseStep(sn, 3, 3)))
    logger.info("Set gain step for ch(%d): %s" %(3, service.setChannelGainStep(sn, 3, 7)))
    logger.info("Set com gain step: %s" %(service.setComGainStep(sn, 9)))

if __name__ == '__main__':
    startService()
    logger.info("end")